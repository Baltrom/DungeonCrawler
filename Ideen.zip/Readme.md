Project Name : Donjons and maybe Drajons
Author : Nikolaus Koch wi26b166

Ich m�chte einen textbasierten Dungeoncrawler bauen.
�ber die Au�ma�e bin ich mir noch nicht sicher.
Auch bin ich mir noch nicht sicher ob ich es �ber if/else statements das abenteuer baue : 
Sprich : text output(storytelling) dann prompt an den user :  chose a b c d 
oder ob ich es �ber freitexteingabe mache und java nach schlagw�rtern suchen lasse um intention des spielers zu "erraten"
es wird einen RNG geben, mit DnD�hnlichen gr��en: D20, D10, D6
Verschiedene klassen m�chte ich dem spieler am anfang zur auswahl geben, mit unterschiedlichen attributen f�r die RNG based "skillchecks" 
so kann ein "mage" vll alte runen lesen und ein "rogue" ein schloss knacken, eine falle entsch�rfen oder akkrobatik checks amchen die der "alte magier" niemals hinkriegt.

